
INSERT INTO dbo.Countries (Code, CountryName, Status)
VALUES ('COL', 'Colombia', 1)
GO

INSERT INTO dbo.Countries (Code, CountryName, Status)
VALUES ('CRI', 'Costa Rica', 1)
GO

