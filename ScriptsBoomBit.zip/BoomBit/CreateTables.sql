IF OBJECT_ID ('dbo.Countries') IS NOT NULL
	DROP TABLE dbo.Countries
GO

CREATE TABLE dbo.Countries
	(
	IdCountry   INT IDENTITY NOT NULL,
	Code        CHAR (3) NOT NULL,
	CountryName NVARCHAR (255) NOT NULL,
	Status      BIT CONSTRAINT DF_Countries_Status DEFAULT ((1)) NOT NULL,
	CONSTRAINT PK__Countrie__F99F104D0603C7E9 PRIMARY KEY (IdCountry)
	)
GO

IF OBJECT_ID ('dbo.Users') IS NOT NULL
	DROP TABLE dbo.Users
GO

CREATE TABLE dbo.Users
	(
	IdUser      INT IDENTITY NOT NULL,
	IdCountry   CHAR (3) NOT NULL,
	UserName    NVARCHAR (100) NOT NULL,
	LastName    NVARCHAR (100) NOT NULL,
	Email       NVARCHAR (255) NOT NULL,
	BirthDate   DATE NOT NULL,
	Phone       NVARCHAR (15) NOT NULL,
	IsContacted BIT NOT NULL,
	Status      BIT CONSTRAINT DF_Users_Status DEFAULT ((1)) NOT NULL,
	DateCreated DATETIME CONSTRAINT DF_Users_DateCreated DEFAULT (getdate()) NOT NULL,
	CONSTRAINT PK_Users PRIMARY KEY (IdUser)
	)
GO

IF OBJECT_ID ('dbo.Activities') IS NOT NULL
	DROP TABLE dbo.Activities
GO

CREATE TABLE dbo.Activities
	(
	ActivityId          INT IDENTITY NOT NULL,
	IdUser              INT NOT NULL,
	DateCreated         DATETIME CONSTRAINT DF__Activitie__creat__3B75D760 DEFAULT (getdate()) NULL,
	ActivityDescription NVARCHAR (255) NOT NULL,
	Status              BIT CONSTRAINT DF_Activities_Status DEFAULT ((1)) NULL,
	CONSTRAINT PK__Activiti__482FBD631D56424B PRIMARY KEY (ActivityId),
	CONSTRAINT FK_Activities_Users FOREIGN KEY (IdUser) REFERENCES dbo.Users (IdUser)
	)
GO

