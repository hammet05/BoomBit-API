INSERT INTO dbo.Users (IdCountry, UserName, LastName, Email, BirthDate, Phone, IsContacted, Status)
VALUES 
('COL', 'Juan', 'P�rez', 'juan.perez@example.com', '1995-06-15', '3204567890', 1, 1),
('CRI', 'Maria', 'L�pez', 'maria.lopez@example.com', '1988-09-22', '3157894561', 0, 1),
('COL', 'Carlos', 'Gonz�lez', 'carlos.g@example.com', '1992-03-10', '3123456789', 1, 0),
('CRI', 'Laura', 'Ram�rez', 'laura.ramirez@example.com', '2000-12-05', '3176541230',1, 0);